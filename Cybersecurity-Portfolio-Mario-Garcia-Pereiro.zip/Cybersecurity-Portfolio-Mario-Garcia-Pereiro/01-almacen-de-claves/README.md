# Almacén de claves en Linux

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

***										***
***	ASIR2-SAD_CHE - Almacén de Claves en Linux - FAP – 01/09/2026		***
***	Uso de la herramienta pass para la creación de un Almacén de Claves	***
***										***


Para realizar este laboratorio se utilizarán las máquinas router y kalitest.
En él se efectuarán prácticas con la herramienta pass para crear un Almacén de Claves para el usuario kali.

pass es el gestor de contraseñas de Unix, sencillo e ideal para scripting, pero basado en GPG y muy robusto.
gopass es la nueva versión de pass en Linux, con más funciones y un uso más cómodo.
Ambos son instalables en Linux y gopass es compatible top-down con pass, si bien requiere una instalación específica desde su repositorio oficial.


INSTALACIÓN DEL SOFTWARE

Arrancar las máquinas router y kalitest.

Asegurarse de que la máquina kalitest tiene conexión a Internet mediante un ping a Google:
ping 8.8.8.8

Ejecutar la siguiente secuencia de comandos de instalación (NO efectuar upgrade):
sudo apt update
sudo apt install -y gnupg2 git curl
sudo apt install -y pass


GENERACIÓN DE CLAVE GPG

Antes de generar la clave GPG para este laboratorio es conveniente comprobar si existen claves anteriores de otros laboratorios  y, en caso afirmativo, borrarlas todas.

Comprobar si existen claves normales:
gpg --list-keys
Si no existen claves, este comando creará toda la estructura de información para albergarlas.

Comprobar si existen claves privadas:
gpg --list-secret-keys

Si alguno de estos comandos indica un problema, reiniciar el contexto con el comando siguiente:
gpgconf --kill all

Borrar todas las claves existentes con el comando siguiente:
rm -rf ~/.gnupg

Borrar también el almacén de claves anterior, en caso de que exista
rm -rf ~/.password-store

Ejecutar de nuevo los comandos de verificación de claves anteriores para asegurar que no queda ninguna de ellas activa. Normalmente, estos comandos recrearán la base de datos de confianza.

Crear el directorio /home/kali/LAB_PASS y entrar en él.

Crear una clave GPG (interactiva, segura) para cifrar las entradas del almacén de claves, con las opciones indicadas:
gpg --full-generate-key

- Tipo: RSA and RSA (1).
- Tamaño: 3072
- Caducidad: la clave nunca caduca (0)
- Correcto: s
- Nombre y Apellidos: un nombre y un apellido
- Correo electrónico: el correo de clase
- Comentario: cualquier texto
- Validación final: OK (V)
- Introducción de contraseña: analistax (indicará que es insegura; aceptar de todas formas)

Obtener y guardar el ID de la clave, necesario para tareas posteriores (pass init), ejecutando el comando siguiente y chequeando el ID que aparece tras "sec  rsa4096/<KEYID>" dentro del fichero de texto:
gpg --list-secret-keys --keyid-format LONG > id_clave.txt

Por ejemplo:
sec   rsa3072/A1095800D510579C 2025-10-19 [SC]
ID: A1095800D510579C


INICIALIZACIÓN DE PASS

Inicializar pass con el ID obtenido en el paso anterior, lo cual creará el directorio del almacén de claves (~/.password-store) en el que se guardarán las entradas cifradas por GPG:
pass init <KEYID>

En el ejemplo:
pass init A1095800D510579C

Si todo va bien, la respuesta será la siguiente:

mkdir: se ha creado el directorio '/home/kali/.password-store/'
Password store initialized for A1095800D510579C


ADICIÓN DE CONTRASEÑAS

Las contraseñas se pueden añadir de modo interactivo. Se pedirá contraseña de administrador y confirmación de la misma:
pass insert ejemplo
clave: prueba

Para ver una entrada del almacén se ejecutará el comando siguiente:
pass show ejemplo
- Para visualizar la información se solicitará la contraseña del administrador del almacén.
- Cada vez que se inicie sesión con el usuario kali, se volverá a solicitar la contraseña de administrador.
- Si se marca el flag "Guardar en gestor de contraseñas", no se solicitará más esta contraseña, aunque se cierre y abra la sesión del usuario kali.

Si se quiere copiar esta información al portapapeles para usarla en otra aplicación, se puede usar la opción -c (esta información se limpiará automáticamente del portapapeles en 45 segundos):
pass -c ejemplo

Se puede comprobar que la información de la clave está en el portapapeles pulsando lo siguiente:
CTRL-SHIFT-V


EDICIÓN DE DATOS DE UNA FICHA DE USUARIO

En primer lugar se identificará el ID de la clave a editar con el comando habitual o consultando el contenido del fichero generado anteriormente:
gpg --list-keys

Ejemplo de salida del comando:

/home/kali/.gnupg/pubring.kbx
pub   rsa3072 2025-10-19 [SC]
      DB1E71C5054A48EC9289BFB2A1095800D510579C
uid        [  absoluta ] Francisco Artes (Texto de Prueba) <francisco.artes@icloud.com>
sub   rsa3072 2025-10-19 [E]

El ID de la clave es el número largo, cuya última parte es el ID de creación. Para editarlo se puede usar completo o parcial, por ejemplo, se pueden usar los últimos 8 caracteres: D510579C

Para entrar en el modo de edición se usará el comando siguiente, que abrirá una consola interactiva de gpg para esta clave:
gpg --edit-key D510579C

Para añadir más datos del usuario se ejecutará el comando:
adduid
La consola pedirá los datos siguientes:
- Nombre real
- Correo electrónico
- Comentario opcional

Se puede añadir también una foto del usuario para su ficha, con el comando siguiente:
addphoto
NOTA: Antes de ejecutar este comando situar un fichero .jpg cualquiera en el directorio LAB_PASS, para poder añadirlo cuando lo solicite la aplicación.

Se puede añadir una subclave para cifrado, firma o autenticación, lo cual es habitual si se rota la clave usada para cifrar. Con el comando siguiente, GPG arrancará un asistente idéntico al utilizado para generar la clave principal:
addkey

Salir guardando con "save" o sin guardar con "quit".

NOTA:
En modo de edición también se puede revocar un UID o subclave con el comando: revuid
O bien, revocar la clave completa con el comando: revkey

Una vez que se dispone de la clave con subclaves y foto embebida, se puede exportar con el comando siguiente, para importarla en otra máquina:
gpg --export D510579C > clave_con_foto.gpg

El fichero de salida es binario, pero se podrá visualizar su estructura con el comando siguiente:
gpg --list-packets clave_con_foto.gpg > estructura.txt


GENERACIÓN AUTOMÁTICA DE CONTRASEÑAS

Generación de contraseña de 24 caracteres y almacenamiento en el almacén de claves:
pass generate ejemplo_auto 24

Visualización de la contraseña generada:
pass show ejemplo_auto


USO EN SCRIPTS E INTEGRACIÓN CON APLICACIONES

Obtener la contraseña en una variable para usarla en un script:
PW=$(pass show ejemplo)

Usar la contraseña $PW en la llamada a una aplicación web o un web Service:
curl -u "usuario:$PW" http://servicio.local/api


LIMPIEZA DEL ALMACÉN DE CLAVES

ATENCIÓN: NO EJECUTAR ESTE PASO ANTES DE LA CORRECCIÓN DE LA PRÁCTICA POR PARTE DEL PROFESOR

Borrado de una entrada:
pass rm -r ejemplo

Borrado TOTAL del almacén de contraseñas (ATENCIÓN):
rm -rf ~/.password-store  # ELIMINAR TODO (¡CUIDADO!)

Borrado del almacén de claves:
gpg --delete-secret-keys <KEYID>
gpg --delete-keys <KEYID>


------------------------------- FIN DEL INSTRUCTIVO -------------------------------

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
