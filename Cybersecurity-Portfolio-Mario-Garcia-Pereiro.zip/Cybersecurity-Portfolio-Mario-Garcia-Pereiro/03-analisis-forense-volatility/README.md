# Análisis forense con Volatility 3

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

***										***
***	ASIR2-SAD_CHE - Herramientas de Análisis Forense - FAP – 01/09/2026	***
***	Volatility3 - Análisis de Volcados de Memoria de Máquinas Comprometidas ***
***										***

Volatility es una herramienta de código abierto para análisis de volcados de memoria de máquinas comprometidas.
- Se utiliza profusamente para la respuesta a incidentes y el análisis de malware.
- Está codificada en Python3 y es compatible con Microsoft Windows, MacOS y Linux.

El escenario habitual es el siguiente:
- Se conecta un pendrive a la máquina comprometida, que contiene un software de volcado de memoria y que graba dicho volcado en el mismo pendrive. De esta forma se evita escribir en el disco de la máquina atacada, que probablemente tendrá que analizarse después sector a sector para recuperar información relevante para los usuarios y recoger trazas del ataque.
- Después se conecta dicho pendrive a otra máquina de análisis en la que estará previamente instalada la herramienta Volatility y se copia el volcado de memoria para su estudio en profundidad.

El escenario de esta práctica será ligeramente diferente al descrito:
- Se arrancará el router vértice del Trípode desde VirtualBox.
- Se descargará una máquina Windows7 preconfigurada desde el servidor de clase. Esta máquina tiene una dirección IP estática de la Intranet del trípode (20.1.1.20), por lo que se deberá conectar a la red interna LAN2.
- Se descargará una máquina Ubuntu Server preconfigurada desde el servidor de clase. Esta máquina tiene una dirección IP estática de la Intranet del trípode (20.1.1.30), por lo que también se deberá conectar a la red interna LAN2.

Una vez preparado el escenario, se seguirán los siguientes pasos:
- En la máquina Windows7 se ejecutará la herramienta DumpIt, que generará un volcado de memoria de dicha máquina y lo dejará en el escritorio.
- Este fichero se renombrará a "volcado.raw".
- Una vez renombrado, se transmitirá por sftp a la máquina Ubuntu mediante Bitvise, ubicándolo en el directorio /home/ubuntu/volatility3
- Si no hubiera espacio suficiente en el disco de la máquina Ubuntu destino, se podrán borrar los ficheros .raw existentes, procedentes de pruebas previas.
- Una vez ubicado el nuevo fichero .raw en dicho directorio, ya se podrá empezar el análisis con Volatility3.

El manual completo de la herramienta Volatility3 se podrá consultar en la ayuda de la herramienta (máquina Ubuntu):
python3 vol.py -h | less

La sintaxis general de la herramienta es la siguiente:
python3 vol.py -f [fichero_raw] [sistema_operativo.plugin]

El FLUJO DE ANÁLISIS FORENSE recomendado contempla la siguiente secuencia de ejecución de plugins:

[Reconocimiento]
- windows.info - Información básica de la RAM capturada
- windows.pslist - procesos en ejecución en el momento de la captura
- windows.pstree - procesos en árbol jerárquico, indicando quién creó a quién

[Detección de anomalías]
- windows.malfind - regiones de memoria de procesos con características compatibles con código inyectado o ejecutable sospechoso
- windows.cmdline - línea de comandos con la que se inició cada proceso

[Extracción de evidencias]
- windows.registry.userassist - información del registro de Windows relacionada con los programas que el usuario ha ejecutado

[Análisis avanzado]
- windows.handles - handles (identificadores de objetos) que tienen abiertos los procesos en el momento de la captura
- windows.vadinfo - análisis de las VAD (Virtual Address Descriptors) de los procesos para entender cómo está organizado el espacio de memoria virtual
- windows.getsids - identificadores de seguridad (SID) que están asociados a cada proceso (con qué cuentas de usuario se están ejecutando los procesos)

PRÁCTICA A EFECTUAR:
- Ejecutar Volatility3 con cada uno de estos plugins y guardar los resultados en 9 ficheros separados y nombrados como sus respectivos plugins.
- Guardar los 9 ficheros resultantes hasta el momento de corrección de esta práctica por parte del profesor.


ANEXO

A continuación se relacionan de forma resumida los plugins más habituales en los análisis de Hacking Ético, aunque hay bastantes más, pues Volatility3 es una herramienta muy potente.


Identificar el sistema operativo y la arquitectura del volcado de memoria
python3 vol.py -f volcado.raw windows.info
Si el volcado no fuera de Windows, Volatility 3 también soporta Linux (linux.*) y MacOS (mac.*)


Listar procesos
python3 vol.py -f memoria.raw windows.pslist


Extraer el historial de procesos o hilos
python3 vol.py -f memoria.raw windows.pstree


Buscar información sobre DLLs cargadas
python3 vol.py -f memoria.raw windows.dlllist


Plugins de Análisis de Procesos
windows.pslist - Lista todos los procesos
windows.pstree - Muestra procesos en formato árbol (relaciones padre-hijo)
windows.psscan - Escanea memoria buscando procesos ocultos o terminados
windows.cmdline - Argumentos de línea de comandos de cada proceso
windows.envars - Variables de entorno de los procesos
windows.dlllist - DLLs cargadas por cada proceso
windows.handles - Handles abiertos por los procesos
windows.getservicesids - SIDs de servicios por nombre de proceso


Plugins de Análisis de Malware y Detección de Inyección
windows.malfind - Detecta código inyectado en procesos (regiones de memoria ejecutables)
windows.ssdt - Tabla de Servicios del Sistema (System Service Descriptor Table)
windows.driverscan - Escanea memoria buscando drivers del kernel
windows.modules - Lista módulos del kernel cargados
windows.callbacks - Callbacks del kernel registrados


Plugins de Análisis de Registro y Configuración
windows.registry.hivelist - Lista hives del registro en memoria
windows.registry.printkey - Muestra claves y valores del registro
windows.registry.userassist - Entradas UserAssist (programas ejecutados)


Plugins de Análisis de Archivos y Artefactos
windows.filescan - Escanea memoria buscando objetos de archivo
windows.dumpfiles - Extrae archivos cacheados en memoria


Plugins de Análisis del Kernel y Sistema
windows.info - Información básica del sistema y versión del kernel
windows.symlinkscan - Escanea enlaces simbólicos
windows.deskscan - Escanea estaciones de escritorio
windows.getsids - SIDs de los procesos
windows.privileges - Privilegios de los procesos
windows.sessions - Sesiones de usuario activas
windows.vadinfo - Información detallada de VAD (Virtual Address Descriptor)


------------------------------- FIN DEL INSTRUCTIVO -------------------------------

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
