# Atribución y condiciones de uso

Este repositorio contiene adaptaciones en Markdown de materiales docentes proporcionados para prácticas de clase. Los documentos originales incluyen referencias a la licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional (CC BY-NC-SA 4.0).

- Licencia: https://creativecommons.org/licenses/by-nc-sa/4.0/
- Autor de la realización y organización de este portfolio: Mario Garcia Pereiro.
- La autoría del material docente original corresponde a sus respectivos autores; este repositorio no la reclama.

La licencia indicada exige atribución, uso no comercial y compartir las adaptaciones bajo la misma licencia. Comprueba que la publicación y redistribución de cada documento está permitida antes de hacer público el repositorio.
