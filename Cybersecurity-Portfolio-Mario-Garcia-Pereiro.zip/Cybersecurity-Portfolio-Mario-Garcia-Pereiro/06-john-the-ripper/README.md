# Auditoría de contraseñas con John the Ripper

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Ataque a Ficheros con John the Ripper


                                    nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Pliego de Descargo
 - Los ejercicios, herramientas y conocimientos contenidos en la Plataforma de Pentesting
   tienen un propósito exclusivamente formativo, por lo que nunca se deberán utilizar con
   fines maliciosos o delictivos.
 - Ningún miembro del claustro docente o de la administración de este centro, serán
   responsables de los daños directos o indirectos que pudieran derivarse del uso
   inadecuado de estas herramientas, que deberán utilizarse sólo en pruebas contra
   sistemas propios o en el curso de auditorías pactadas con los propietarios de los
   sistemas objetivo de los ataques.




                                         www.peruweek.pe



John the Ripper & Crunch – Una Pareja Fatal para las Claves
 - Como se ha visto en laboratorios anteriores, Crunch es uno de los constructores de
   diccionarios de propósito general más utilizados en Internet.
 - Por otra parte, John the Ripper es el cracker de passwords de ficheros más popular
   y efectivo, y trabaja con base en códigos hash.
 - Existen en Internet multitud de herramientas de extracción de hash de los
   diferentes tipos de ficheros, para dar material de trabajo a John the Ripper.
 - La combinación de Crunch y John resulta ser una pareja fatal para cualquier sistema
   de claves, porque puede que lleve su tiempo, pero John siempre encuentra la clave
   buscada.
 - La estrategia para acortar los tiempos de búsqueda está basada en Ingeniería
   Social, esto es, espionaje puro y duro, ya sea a través de personas, de stealers, de
   keyloggers, o de robots de cualquier tipo, para preparar buenos diccionarios.
 - Si John se lanza sin un diccionario, probará todas las credenciales (Fuerza Bruta).



Instalación de LibreOffice en kalitest
- Instalar LibreOffice en kalitest, pues
  esta suite será necesaria para este
  laboratorio y para otras prácticas:
   sudo apt update
   sudo apt install libreoffice

- Una vez instalado, situarse en la casilla
  de búsqueda de aplicaciones (esquina
  superior izquierda), teclear
  “libreoffice” y arrastrar la aplicación
  “LibreOffice” al Escritorio para crear un
  icono de arranque.
- Crear el directorio siguiente y realizar
  todo el laboratorio dentro de él:
   /home/kali/LAB_JOHN





Creación de un fichero de Office cifrado con Contraseña
- Abrir LibreOffice Calc Spreadsheet, que es la aplicación compatible con Microsoft Excel.
- Crear una hoja de cálculo con contenido secreto denominada /home/kali/guarida.xlsx, cifrarla
  con una clave sencilla para que el proceso de cracking no se extienda demasiado (Ab#1) y
  salvarla con formato Microsoft Excel 2010 (.xlsx).
- El contenido secreto puede ser cualquiera, por ejemplo:





Preparación del Entorno de Trabajo
 - A continuación, se preparará un conjunto de scripts sencillos para poder repetir
   el ataque de forma rápida y secuenciada por pasos.
 - Esta técnica es habitual dentro de los equipos corporativos de pentesting.





Script – 0.limpiar_directorio
- Borrar restos de ejecuciones anteriores para mantener limpio el directorio de trabajo.
- Contenido del script:
   rm diccionario.lst
   rm hash_guarida





Script – 1.borrar_claves
- John the Ripper suele venir instalado por defecto en Kali.
- Se puede instalar también fácilmente sobre el resto de las distribuciones de Linux, no
  obstante, sólo la versión Jumbo es capaz de crackear claves de ficheros con potencia
  suficiente.
- Verificar que está instalada la versión Jumbo simplemente tecleando john. Si no lo está,
  actualizar el sistema e instalar la última versión de john.
- Borrar el histórico de passwords crackeadas por John en posibles ejecuciones anteriores,
  eliminando el contenido del directorio /home/kali/.john
- En este directorio también se guarda el log de trabajo de John.
- Contenido del script:
   rm -f /home/kali/.john/*





Script – 2.extraer_hash
- Instalar el paquete John-data, que contiene los extractores de hash más habituales:
   sudo apt update
   sudo apt install john-data
- El hash es un conjunto de caracteres generados a partir de una clave mediante un algoritmo.
- Contenido del script:
   office2john guarida.xlsx > hash_guarida





Script – 3.crear_diccionario
- Crear el diccionario con crunch usando pistas de
  ingeniería social (espionaje), esto es: una letra
  mayúscula, una minúscula, un símbolo y un
  dígito.
- Las dimensiones de los diccionarios crecen
  exponencialmente al incorporar más caracteres
  y más variaciones de los mismos (letras,
  números, símbolos).
- John también puede trabajar sin diccionario,
  comprobando por orden TODAS las
  posibilidades (Fuerza Bruta, modo incremental)
- Contenido del script:
   crunch 4 4 -t ,@^% -o diccionario.lst




Script – 4.atacar_fichero
- Lanzar el proceso de cracking de la password sobre el fichero que contiene el hash,
  utilizando el diccionario creado en el paso anterior.
- Cuando john localiza la password, la muestra por pantalla y la almacena en su
  fichero histórico john.pot. Si se intenta crackear un hash ya procesado, john
  comprueba primero si lo tiene dentro de su histórico, y si lo encuentra no relanza el
  proceso. Por eso, si se cambia la password de un fichero y se quiere reintentar el
  proceso, primero se tendrá que borrar el histórico.
- Contenido del script:
   john --wordlist=diccionario.lst hash_guarida





Script – 5.mostrar_claves
- Para ver si un fichero de hash ya fue crackeado, se puede consultar el histórico
  de forma específica sobre el fichero que contiene el hash.
- La información se guarda en el fichero /home/kali/.john/john.pot
- Para efectuar una nueva ejecución habrá que borrar el fichero john.pot, o bien,
  el directorio /home/kali/.john completo, como se hace en el paso 1.
- Contenido del script:
   john --show hash_guarida





La Complejidad Creciente de los Diccionarios
 - En las siguientes capturas de pantalla se puede comprobar como la complejidad del
   diccionario escala exponencialmente a medida que se van añadiendo caracteres.
 - Con la complejidad del diccionario también escala el tiempo que dura un ataque, por lo
   que, si se quiere complicar la labor de los hackers, lo mejor es usar claves complicadas y
   cambiarlas a menudo.




                 - Diccionario con palabras de 4 minúsculas: 2 MB.





La Complejidad Creciente de los Diccionarios
 - Diccionario con palabras de 5 minúsculas: 67 MB.




 - Diccionario con palabras de 6 minúsculas: 2 GB.





La Complejidad Creciente de los Diccionarios
 - Diccionario con palabras de 7 minúsculas: 59 GB.




 - Diccionario con palabras de 8 minúsculas: 1,7 TB





Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
