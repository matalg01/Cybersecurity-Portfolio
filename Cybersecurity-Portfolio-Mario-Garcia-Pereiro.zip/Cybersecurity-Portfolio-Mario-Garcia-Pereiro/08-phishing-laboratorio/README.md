# Laboratorio de phishing e ingeniería social

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Creación de un Phisher


                                   nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Ingeniería Social – Instalación de un Phisher
- Existen multitud de técnicas, tácticas, herramientas y estrategias de Ingeniería Social, pero la más
  relevante y potente de todas ellas es el Phishing.
- El Phishing permite emular websites auténticos de forma prácticamente idéntica, para robar las
  credenciales de usuario.
- El usuario casi no nota nada, pues efectúa un primer acceso al falso website, introduce sus
  credenciales y navega un poco, pero algo parece no funcionar bien, por lo que sale de la página,
  teclea de nuevo la dirección y vuelve a entrar, esta vez probablemente al sitio auténtico, pero ya le
  habrán robado los datos.
- Existen muchas herramientas de código abierto denominadas phishers, que permiten efectuar
  este tipo de captura de datos.
- Un phisher permite emular muy bien un conjunto de websites muy populares, pero también
  permite al usuario crear a medida el website falso que precise.
- En esta práctica se descargará un phisher clásico desde GitHub y se emularán varias páginas web
  populares.

                                                                      IMPORTANTE: NO USAR NUNCA EN INTERNET



Primer Requerimiento – Instalación de php y Apache
- Casi todos los phishers se apoyan en el webserver de código abierto Apache y en php.
- Apache es multiplataforma y tiene la ventaja de ser también la base de muchos websites
  auténticos, lo cual brinda aún más similitud. Instalar ambos productos en kalitest.





Arranque de Apache y Comprobación de Estado




            - Consolidarlo con un enable si se desea que arranque con la máquina.

Segundo Requerimiento – Instalación de wget, unzip y curl
 El phisher seleccionado requiere asimismo la instalación de las siguientes herramientas
 sobre Linux, que generalmente vienen ya instaladas:
 - wget. Herramienta de descarga directa de contenidos desde páginas web.
 - unzip. Descompresor de archivos clásico.
 - curl. Intérprete de comandos para cursar peticiones a través de una red.





Clonación de un phisher desde GitHub
- Para esta práctica se
  clonará desde GitHub
  un phisher clásico de
  código abierto
  denominado
  precisamente, Phisher.
- Esta herramienta
  permite emular
  fácilmente los sitios
  web de redes sociales
  y otros sites muy
  extendidos.




Emulación de Webs
- Además de emular
  varios websites
  populares por defecto,
  aunque en versión
  antigua, Phisher permite
  al usuario diseñar su
  propia emulación para el
  sitio que desee.
- Tras clonar el SW de la
  aplicación, se ejecutará
  con bash, según se
  indica en sus
  instrucciones (atención
  al Disclaimer).



Ingeniería Social
- En la primera ejecución se lanza
  el servidor php y se descarga
  automáticamente ngrok.
- ngrok sirve para exponer en
  Internet los servidores locales
  situados tras NATs y
  cortafuegos, mediante túneles
  seguros.
- En resumidas cuentas, ngrok
  permite exponer en Internet un
  servidor de red que está
  corriendo en una máquina local,
  que en este caso estará
  simulando ser un portal real.



Ingeniería Social
- En este ejercicio se emularán páginas web antiguas, con objeto de despistar al usuario y
  hacer que introduzca sus credenciales de acceso.
- NOTA IMPORTANTE: Esta práctica tiene un propósito exclusivamente formativo. Las
  herramientas y procedimientos descritos en ella no deben utilizarse bajo ningún concepto
  para fines maliciosos. Tanto el centro como el autor declinan cualquier responsabilidad
  ante uso malicioso de este SW.




                               www.peruweek.pe



Ingeniería Social
- Una vez lanzado Phisher, se accederá
  a la página local de ngrok:
   http://localhost:3333
- Esta dirección se enviará al usuario
  convenientemente enmascarada, para
  que parezca la dirección auténtica.
- Se presenta la página falsa, que es
  prácticamente idéntica a la real.
- Se espera a que el usuario introduzca
  sus credenciales auténticas.
- Una vez introducidas las credenciales,
  éstas quedan capturadas
  inmediatamente.



Ingeniería Social
- Las credenciales capturadas en la página falsificada se muestran directamente por
  pantalla en el terminal que abrió la sesión, y además se almacenan en un fichero de texto.





Ingeniería Social
- Después del robo de credenciales, el phisher redirige al usuario a la página auténtica de la
  red social. Como se trata de un phisher antiguo, se puede ver que esta página tiene un
  diseño más moderno.





Ingeniería Social
- Ejemplo de emulación de la página real de entrada a Facebook.





Ingeniería Social
- Ejemplo de emulación de la página real de
  entrada a Spotify y captura de las credenciales
  de usuario de la forma habitual.





Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
