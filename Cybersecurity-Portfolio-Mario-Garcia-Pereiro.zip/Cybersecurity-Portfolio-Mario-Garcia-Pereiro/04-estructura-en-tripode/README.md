# Estructura de red en trípode

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Estructura en Trípode


                                   nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Estructura en Trípode (three-legged structure)
 - Cuando se utiliza una estructura three-legged o
   en Trípode desde la WAN sólo se puede
   acceder a una serie de máquinas preparadas
   para dar servicio hacia el exterior, que
   protegen la LAN de ataques. Estas máquinas
   son la Zona Desmilitarizada o DMZ, y son la
   clave de la Seguridad Perimetral.
 - En esta estructura, sólo ciertas máquinas de la
   DMZ pueden acceder a la LAN en la que se
   sitúan los servidores con información sensible,
   no permitiéndose nunca el acceso directo
   desde la WAN a la LAN.




Topología Lógica de la Estructura en Trípode del Laboratorio
 Para implementar la estructura en
 trípode en este laboratorio, las                                    kalitest
                                                                 host de intranet                            kalisoc
 máquinas tendrán el papel siguiente:                                                                  zona desmilitarizada
                                                                                                             (DMZ)
 - router será el vértice.
 - kalisoc será la zona desmilitarizada.
 - kalitest será el host de la intranet                                      eth0
                                                                                           20.1.1.0
                                                                           20.1.1.10
   en el que se guarda la información                                                       (LAN2)
                                                                                                                     eth0           eth0
   valiosa de la empresa.                                                                                           10.1.1.1      10.1.1.10
                                                                                                                          10.1.1.0
                                                                                                 eth2                      (LAN1)
                                                                                                20.1.1.1

                                                                                                            eth1
                                                                                           router          (DHCP)
                                                                                       router frontera                                  Conexión al ISP
                                                                                                                        DHCP
                                                                                          (vértice)                    (Bridge)





Clonación y Asignación de Nombre a las Máquinas Virtuales
 - Estas tres máquinas se implementarán clonando kalibre tres veces y reservando sin uso
   la máquina kalibre original (master).
 - Se seleccionará “Clonación Completa” y “Generar nuevas direcciones MAC para todos
   los adaptadores de red”.
 - Se nombrarán las máquinas con los nombres indicados en VirtualBox y después se les
   asignará el nombre de host correspondiente una vez arrancadas, mediante la siguiente
   secuencia de comandos:
   sudo nano /etc/hostname
   -> kalisoc
   sudo nano /etc/hosts
   -> 127.0.1.1     kalisoc
   Sudo reboot





Networking - router
 - Adaptador 1 (eth0) – Red Interna LAN1 – 10.1.1.1                                         auto eth0
                                                                                            iface eth0 inet static
 - Adaptador 2 (eth1) – Adaptador Puente (Bridge) – DHCP                                    address 10.1.1.1
 - Adaptador 3 (eth2) – Red Interna LAN2 – 20.1.1.1                                         netmask 255.255.255.0
                                                                                            #gateway

 IMPORTANTE: Respetar la denominación literal de las
                                                                                            auto eth1
 redes internas, siempre en mayúsculas.
                                                                                            iface eth1 inet dhcp


                                                                                            auto eth2
                                                                                            iface eth2 inet static
                                                                                            address 20.1.1.1
                                                                                            netmask 255.255.255.0
                                                                                            #gateway




Networking - kalisoc
 - Adaptador 1 (eth0) – Red Interna LAN1 – 10.1.1.10                            auto eth0
                                                                                iface eth0 inet static
                                                                                address 10.1.1.10
 - IMPORTANTE: Respetar la denominación literal de                              netmask 255.255.255.0
   las redes internas, siempre en mayúsculas.                                   gateway 10.1.1.1
                                                                                dns-nameservers 8.8.8.8





Networking - kalitest
 - Adaptador 1 (eth0) – Red Interna LAN2 – 20.1.1.10                            auto eth0
                                                                                iface eth0 inet static
                                                                                address 20.1.1.10
 - IMPORTANTE: Respetar la denominación literal de                              netmask 255.255.255.0
   las redes internas, siempre en mayúsculas.                                   gateway 20.1.1.1
                                                                                dns-nameservers 8.8.8.8





Activación del enrutamiento en la máquina router
 - Poner a 1 el flag de enrutamiento en el router, editando el fichero que se indica a
   continuación.
 - Este flag tendrá efecto cuando se ejecute el fichero /root/ARRANCAR_ROUTER cuyo
   contenido se indica en la página siguiente.
   sudo nano /etc/sysctl.conf


   ######################
   net.ipv4.ip_forward=1
   ######################





Contenido del Script /root/ARRANCAR_ROUTER
 # Activar y comprobar el enrutamiento
 sudo sysctl -p
 cat /proc/sys/net/ipv4/ip_forward


 # Limpiar reglas de enrutamiento anteriores
 sudo iptables -F
 sudo iptables -t nat -F
 sudo iptables -X


 # Reenvío de paquetes
 sudo iptables -A FORWARD -j ACCEPT


 # Conexión con Internet desde LAN1
 sudo iptables -t nat -A POSTROUTING -s 10.1.1.0/24 -o eth1 -j MASQUERADE


 # Conexión con Internet desde LAN2
 sudo iptables -t nat -A POSTROUTING -s 20.1.1.0/24 -o eth1 -j MASQUERADE





Consolidación del enrutamiento en router
 - Editar la crontab de root. Si es la primera edición, seleccionar el editor nano.
 - Añadir al final del fichero el comando de lanzamiento del script ARRANCAR_ROUTER.
   sudo su
   crontab –e
   ##############################
   @reboot /root/ARRANCAR_ROUTER
   ##############################


 - Reiniciar la máquina y comprobar que el flag sea "1“ mediante el comando cat.
 - Si el flag tiene el valor correcto, la configuración del router habrá finalizado.
   cat /proc/sys/net/ipv4/ip_forward





Instalación y Configuración del Firewall en kalitest
  Instalar y preconfigurar ufw en kalitest:
  - sudo apt install ufw
  - sudo ufw enable
  - sudo ufw status

  Añadir las tres reglas siguientes para asegurar que sólo la máquina de la zona
  desmilitarizada (kalisoc) se puede conectar a la máquina de la intranet (kalitest):
  - sudo ufw default deny incoming. Bloqueo del tráfico entrante en todos los puertos, a
    excepción de los que se abran con sentencias posteriores a ésta.
  - sudo ufw default allow outgoing. Apertura del tráfico saliente desde todos los puertos,
    para que kalitest se pueda conectar a cualquier host de intranet e Internet.
  - sudo ufw allow from 10.1.1.10. Apertura de cualquier tipo de conexión y por cualquier
    puerto desde la máquina 10.1.1.10 (kalisoc, zona desmilitarizada).



Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
