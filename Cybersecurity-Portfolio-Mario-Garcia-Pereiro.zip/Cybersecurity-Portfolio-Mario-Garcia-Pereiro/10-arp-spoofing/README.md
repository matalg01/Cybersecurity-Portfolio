# Man-in-the-Middle mediante ARP Spoofing

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Man in the Middle – ARP Spoofing


                                    nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Pliego de Descargo
 - Los ejercicios, herramientas y conocimientos contenidos en esta documentación tienen
   un propósito exclusivamente formativo, por lo que nunca se deberán utilizar con fines
   maliciosos o delictivos.
 - Ningún miembro del claustro docente o de la administración de este centro, serán
   responsables de los daños directos o indirectos que pudieran derivarse del uso
   inadecuado de estas herramientas, que deberán utilizarse sólo en pruebas contra
   sistemas propios, en laboratorios, o en el transcurso de auditorías pactadas con los
   propietarios de los sistemas objetivos de los ataques.




                                                    www.peruweek.pe



La Inseguridad de la TCP/IP Protocol Suite
- La familia de protocolos TCP/IP data de los años 70. El HW de esa época era limitado y el
  diseño de la torre se orientó a la fiabilidad y no a la seguridad.
- TCP/IP es muy inseguro en sí mismo y necesita protecciones y refuerzos añadidos para ser
  menos vulnerable.




                                                                                                     https://hard2bit.com





El Ataque del Intermediario – Man in the Middle
- El ataque más sencillo, habitual y peligroso es el del Intermediario o Man-In-The-Middle
  (MitM), en el que se interpone un equipo entre otros dos que se están comunicando,
  consiguiendo que todos los paquetes pasen por él, monitorizándolos o alterándolos. Este
  ataque tiene dos modalidades:
    - Por HW. El atacante se interpone físicamente en el camino, por ejemplo, en la conexión
      de uno de los equipos a su switch más próximo, para lo cual necesita dos puertos
      Ethernet.
    - Por SW. El atacante no precisa acceso físico, pues manipula los paquetes para que cada
      uno de los interlocutores remotos crea que él es su interlocutor auténtico.



                                                                                                           https://blog.pradeo.com





 Las Modalidades de Ataque MitM
     SITUACIÓN
       NORMAL
                     A                                                                                                       B
  A SE HABLA CON B




      MITM HW
 C SE INTERPONE EN
                     A                    C                                                                                  B
    LA CONEXIÓN




      MITM SW
 C SUPLANTA A LOS
                     A                                                                                                       B
DOS INTERLOCUTORES




                                                                      C



El Protocolo ARP – Address Resolution Protocol – IP & MAC





El Envenenamiento ARP – ARP Poisoning o Spoofing
- El protocolo ARP se utiliza para obtener la Dirección MAC asociada a una IP.
- Cuando la Máquina A quiere comunicarse con la Máquina B y conoce su dirección IP (Nivel
  3), obtiene la Dirección MAC (Nivel 2) mediante ARP (Nivel 3).
- Para ello, A lanza un paquete de Difusión (Broadcast) que llega a todos los equipos,
  preguntando por la MAC-B de IP-B. Sólo B debería responder a este paquete.
- Si una Máquina C envía paquetes de respuesta ARP sin que nadie le haya preguntado nada,
  el protocolo es tan débil que estas respuestas son aceptadas por A y B, sin validarlas ni
  relacionarlas con una posible pregunta anterior.
- Así pues, C convence a A de que MAC-C es la MAC de B, y a B de que MAC-C es la MAC de A
                                      RESPUESTA ARP                       RESPUESTA ARP
                                       ESPONTÁNEA                          ESPONTÁNEA
                          A                                   C                                   B
                                          ACK                                   ACK





Contramedidas MitM
- Tablas ARP estáticas, dada la debilidad del protocolo ARP dinámico. Supone mucho trabajo
  de mantenimiento si se instalan equipos nuevos o tarjetas nuevas.
- Control del acceso físico y lógico a la red. Si el atacante no puede conectar su equipo,
  tampoco podrá lanzar paquetes maliciosos.
- Protocolos seguros con infraestructura de clave pública. Cualquier interceptación de
  mensajes no será provechosa y el atacante no podrá suplantar a los extremos.
- Introducción de un NIPS o un Sniffer (Network Intrusion Prevention System), que alerte de la
  presencia de respuestas ARP no solicitadas.
La inmensa mayoría de las IP de los paquetes que circulan por una red deben estar asociadas a
única MAC, por lo que si se detecta una asignación duplicada se deberá sospechar, salvo en el
caso de las arquitecturas de Alta Disponibilidad en las que hay un Nodo Activo y otro de
Respaldo. En este último caso, la IP estará asociada a dos tarjetas de red, pero éstas no estarán
activas nunca de forma simultánea.



Preparación del Escenario de la Práctica – MitM SW
- El atacante no precisa acceso físico, pues manipula los paquetes para que cada uno de los
  interlocutores remotos crea que él es su interlocutor auténtico y los suplanta a ambos.
- El escenario de la práctica estará compuesto por tres máquinas virtuales Kali Linux sobre un
  hipervisor VirtualBox.
- La máquina kali3 interceptará las comunicaciones entre kali1 y kali2, haciéndose pasar por
  ambos para capturar y monitorizar sus paquetes de datos.

      kali1                                                                                                                    kali2




                                                          kali3





Preparación Laboratorio MitM – Topología Lógica DMZ
                                               - Renombrar kalisoc a kali1, en VirtualBox y como
                                                 hostname.
                                               - Clonar kalibre en kali2 y kali3, asignando las direcciones
                                                 indicadas en el gráfico (ver página siguiente).
                                               - Conectar las tres máquinas a LAN1 (DMZ).
                                               - Arrancar el router para tener conexión a Internet.
                                               - Instalar Ettercap en kali3 (host atacante):
                                                     sudo apt update
                                                     sudo apt install ettercap-graphical
                                               - Instalar FPT Server en kali1, como protocolo vulnerable:
                                                     sudo apt update
                                                     sudo apt install vsftpd
                                                     sudo systemctl start vsftpd
                                                     sudo systemctl enable vsftpd
                                               - Para finalizar, probar la conexión FTP de kali2 a kali1.
                                               - Apagar el router para que no interfiera en la práctica y
                                                 para aislar de Internet a la sandbox.


Networking – kali2 y kali3
     - Kali2 - Adaptador 1 (eth0) – Red Interna LAN1                        auto eth0
                                                                            iface eth0 inet static
                                                                            address 10.1.1.20
                                                                            netmask 255.255.255.0
                                                                            gateway 10.1.1.1
                                                                            dns-nameservers 8.8.8.8




     - Kali3 -Adaptador 1 (eth0) – Red Interna LAN1                         auto eth0
                                                                            iface eth0 inet static
                                                                            address 10.1.1.30
                                                                            netmask 255.255.255.0
                                                                            gateway 10.1.1.1
                                                                            dns-nameservers 8.8.8.8




ARP Spoofing con Ettercap
- El sistema operativo Kali Linux incorpora más de 666 herramientas de Hacking Ético, entre las
  que se encuentra Ettercap, la reina del spoofing.
- Esta herramienta permite realizar ataques de ARP Poisoning, NDP Poisoning, ICMP Redirect,
  Port Stealing, DHCP Spoofing y SSL Intercept.
- Una vez montado el esquema MitM, si el protocolo es sencillo o débil, Ettercap obtendrá y
  mostrará las credenciales directamente en su consola de mensajería.
- Si el protocolo es complejo o está cifrado, Ettercap no extraerá las credenciales, pero
  permitirá trabajar en la máquina con los paquetes desviados y capturados, visualizándolos
  mediante Tshark, Wireshark, etc. y estudiándolos mediante Data Analytics.





- Arrancar las máquinas kali1, kali2 y kali3.
- Abrir una shell en kali1 y kali2.
- Buscar la herramienta Ettercap en kali3 y
  lanzarla en modo gráfico.





- Ettercap requiere permisos especiales, por lo
  que solicitará la clave del usuario.




- Marcar las opciones de
  arranque según se muestra
  y pulsar el botón CHECK.





- Ettercap arrancará e imprimirá los datos
  de contexto: interfaz de ethernet en
  muestreo, MAC Address de la misma, etc.



- Solicitar a Ettercap
  que rastree los hosts
  activos en la LAN.





- Finalizado el rastreo, Ettercap
  indicará cuántos hosts ha encontrado.




- Indicar a la
  herramienta que
  muestre los hosts
  localizados.





- Se visualizarán las IPs y MACs
  de los hosts localizados.





- Seleccionar el primer host                                  • Ver contenido de la tabla ARP, seleccionando
  (kali1) y añadirlo al Target1.                                los datos de eth0.




                                                                                 - Ver contenido de la tabla ARP



- Seleccionar el segundo host
  (kali2) y añadirlo al Target2.




         - Ettercap confirmará
           la adición de los
           hosts a los targets.




- Iniciar el ARP Poisoning
  en Ettercap.





- Parametrizar el ARP Poisoning para que kali3
  suplante a los dos interlocutores remotos.





                                                                                         - Al chequear los
                                                                                           contenidos de las tablas
                                                                                           ARP, se verá que las
                                                                                           MACs de kali1 y kali2 ya
                                                                                           son ambas la de kali3,
                                                                                           por lo que el ataque
                                                                                           está en marcha.




- Ettercap indicará que
  los objetivos ya han
  sido intervenidos.





- Si se lanza una conexión FTP de
  kali2 a kali1, se comprobará que
  Ettercap capturará sin
                   sin   problemas
                       problemas
  las credenciales suministradas.





- Finalizada la captura de
  credenciales, se cierra la
  conexión FTP y se desactiva
  el ARP Poisoning en Ettercap.





- Al chequear de
              losnuevo los
  contenidos de las tablas
  ARP, se verá que las
  MACs de kali1 y kali2 ya
  han
  son vuelto
      ambas la ser las
               de kali3,
  correctas,
  por lo que por lo que el
             el ataque
  ataque
  está nhabrá  finalizado.
          marcha.





- En caso de que haya algún problema
  para desactivar el ARP Poisoning, o
  que Ettercap deje de ejecutarse por
  alguna razón, se podrá ejecutar el
  comando indicado para vaciar las
  tablas ARP.
- Estas tablas se irán poblando
  automáticamente a medida que se vaya
  cursando tráfico de nuevo entre las
  máquinas de la LAN.





Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
