# Autenticación MFA con Google Authenticator

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

***										***
***	ASIR2-SAD_CHE - Gestión y Uso de Tokens - FAP – 01/09/2025		***
***	Autentificación de Acceso a Kali Linux con Google Authenticator		***
***										***

En este instructivo se generarán códigos de un solo uso basados en el tiempo (TOPT, Time-based One-Time Password), para autorizar el login del usuario kali en la máquina kalitest mediante SSH.


REQUISITOS

Este instructivo requiere arrancar la estructura en trípode creada en la práctica al efecto, a saber:
- Vértice del Trípode: router
- Zona Desmilitarizada: kalisoc
- Intranet: kalitest

Por otra parte, también se requiere un móvil Android o iOS


INSTALACIÓN DE SOFTWARE

Instalar la App Google Authenticator en un móvil Android o iOS, sin arrancarla por el momento.

Abrir un terminal en kalitest y comprobar que se accede a Internet correctamente:
ping 8.8.8.8

Actualizar la máquina SIN efectuar un upgrade:
sudo apt update
sudo apt autoremove
sudo apt autoclean

A continuación se instalará en Kali Linux el módulo PAM (Pluggable Authentication Module), que es un mecanismo para integrar múltiples autentificaciones de bajo nivel en una aplicación de alto nivel.

PAM desacopla la autenticación de las aplicaciones, permitiendo centralizar y flexibilizar los mecanismos de autenticación para servicios como SSH, en lugar de codificar los métodos en cada aplicación.

PAM permite usar archivos de configuración (/etc/pam.d/sshd) para definir políticas, por ejemplo: exigir contraseñas fuertes, implementar autenticación de dos factores (2FA) o bloquear cuentas tras varios intentos fallidos de inicio de sesión.

Instalar el módulo PAM para TOTP:
sudo apt install libpam-google-authenticator

Ejecutar el autentificador, respondiendo afirmativamente a todas las preguntas que haga:
google-authenticator

Se generará un QR y una clave alfanumérica.
Conservar la clave alfanumérica y proseguir con la práctica.

Arrancar la App Google Authenticator en el móvil, marcando la opción "Usar sin una cuenta".
Pulsar la opción "Añadir código" y escanear el QR generado por google-authenticator en Kali Linux.

Introducir en Google Authenticator (sesión en kalitest) el código indicado por la App del móvil para el usuario en cuestión, que se irá refrescando periódicamente.

La respuesta debe ser "Code Confirmed".

Respaldar los códigos de rescate ante emergencias, que aparecerán de la forma siguiente:

Responder afirmativamente al resto de preguntas que haga el programa.

Configurar PAM para SSH editando el fichero siguiente:
sudo nano /etc/pam.d/sshd

Añadir la siguiente sentencia al principio del fichero, salvarlo y salir:
auth required pam_google_authenticator.so

Editar el fichero de configuración de SSH:
sudo nano /etc/ssh/sshd_config

Asegurar que existen los parámetros siguientes, ambos con valor "yes":
ChallengeResponseAuthentication yes
PasswordAuthentication yes

Salvar el fichero, salir y reiniciar el proceso SSH, verificando que queda correctamente arrancado:
sudo systemctl restart ssh
sudo systemctl status ssh

NOTA: Si hubiera algún problema con estos comandos, reinstalar el openssh-server, volverlo a configurar, configurar PAM y rearrancarlo después.

Con la estructura en trípode activa (firewall), sólo se podrá entrar en kalitest desde kalisoc. Si está desactivada, también se podrá entrar desde el router:
ssh kali@20.1.1.10

NOTA: Si aparece el aviso "REMOTE HOST IDENTIFICATION HAS CHANGED", borrar el fichero /home/kali/.ssh/known_hosts y repetir el comando anterior.

A partir de este momento, la máquina kalitest pedirá el código de verificación de seis dígitos (ver App del móvil, que se refresca cada 30 segundos) y la clave del usuario kali, por lo que ya habrá quedado activa la autentificación de múltiple factor, en este caso basada en un token generado por la App del móvil.

NOTA: En caso de que no funcione la autentificación con token a la primera, borrar el fichero siguiente en kalitest y realizar de nuevo el proceso ejecutando de nuevo google-authenticator:
sudo rm -f /home/kali/.google_authenticator


------------------------------- FIN DEL INSTRUCTIVO -------------------------------

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
