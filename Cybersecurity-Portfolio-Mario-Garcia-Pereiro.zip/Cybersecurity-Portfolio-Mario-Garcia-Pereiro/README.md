# Portfolio de Ciberseguridad — Mario Garcia Pereiro

Repositorio de prácticas y laboratorios realizados en el ámbito de **Ciberseguridad y Hacking Ético (ASIR 2)**. Los documentos se han organizado en Markdown para facilitar su lectura, consulta y seguimiento desde GitHub.

> **Autor de la realización y documentación:** Mario Garcia Pereiro.
> **Procedencia:** material docente facilitado por el profesor y trabajado en clase. La atribución al material original se mantiene; este repositorio no reclama la autoría de los enunciados ni de los contenidos docentes.

## Laboratorios

| # | Laboratorio | Temas principales |
|---:|---|---|
| 01 | [Almacén de claves en Linux](01-almacen-de-claves/README.md) | `pass`, GPG y gestión de credenciales |
| 02 | [Autenticación MFA](02-autenticacion-mfa/README.md) | TOTP, Google Authenticator y SSH |
| 03 | [Análisis forense con Volatility 3](03-analisis-forense-volatility/README.md) | Análisis de volcados de memoria |
| 04 | [Estructura en trípode](04-estructura-en-tripode/README.md) | Segmentación de red, router y firewall |
| 05 | [Cifrado simétrico y asimétrico](05-cifrado-simetrico-y-asimetrico/README.md) | Hash, criptografía y gestión de claves |
| 06 | [John the Ripper](06-john-the-ripper/README.md) | Auditoría de hashes y contraseñas |
| 07 | [Medusa e inventario de activos](07-medusa-inventario-activos/README.md) | MariaDB e identificación de riesgos de autenticación |
| 08 | [Phishing e ingeniería social](08-phishing-laboratorio/README.md) | Laboratorio de phishing |
| 09 | [Hydra y diccionarios](09-hydra-y-diccionarios/README.md) | Auditoría de autenticación y fuerza bruta controlada |
| 10 | [ARP Spoofing](10-arp-spoofing/README.md) | MITM, ARP y análisis de tráfico |

## Aviso de uso responsable

Todas las técnicas descritas deben utilizarse exclusivamente en laboratorios propios o en sistemas para los que se disponga de autorización expresa. Algunas prácticas incluyen herramientas ofensivas; su presencia aquí tiene una finalidad formativa y de aprendizaje de medidas defensivas.

## Atribución y licencia

Los laboratorios parten de documentación docente. Se mantiene la atribución al material original y, cuando el documento fuente lo indica, la referencia a [Creative Commons BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Antes de publicar el repositorio como público, conviene confirmar que la licencia y las condiciones del centro permiten redistribuir los materiales adaptados.

La aportación de Mario Garcia Pereiro consiste en la realización de las prácticas y en la organización/conversión de los documentos para su presentación como portfolio.
