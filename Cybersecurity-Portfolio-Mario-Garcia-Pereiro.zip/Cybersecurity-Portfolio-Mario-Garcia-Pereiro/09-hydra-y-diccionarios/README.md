# Auditoría de autenticación con Hydra y diccionarios

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Creación de Diccionarios y Ataques con Hydra


                                      nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Ataques con Hydra + Diccionarios de Crunch
- Hydra (thc-hydra) es una herramienta de ataque de contraseñas muy usada en entornos de
  seguridad informática. Es un password cracker que automatiza intentos de acceso contra
  servicios remotos usando ataques de fuerza bruta o ataques por diccionario (lista de
  contraseñas).
- Se encuentra habitualmente en distribuciones de auditoría como Kali Linux, no obstante,
  también se puede instalar desde los repositorios Linux habituales.
- Sirve para comprobar la resistencia de autentificaciones remotas y para encontrar
  credenciales débiles en servicios de red.
- Es una potente herramienta de hacking ético, por lo que no debe usarse contra sistemas sin
  permiso explícito de sus propietarios o usuarios.
- Se suele emplear para varias labores, siempre con autorización previa:
   - Auditorías de seguridad (pentesting).
   - Evaluación de políticas de contraseñas.
   - Tests de red-team en entornos controlados (simulación profesional de ataques reales).

                         IMPORTANTE: HYDRA NO DEBE USARSE NUNCA EN INTERNET
                                                                                                                                  Hydra

Hydra – Protocolos y Servicios
 - Hydra soporta muchísimos módulos/protocolos, entre los que se cuentan los siguientes:


            - ssh                    • vnc
            - ftp                    • smtp
            - telnet                 • Imap
            - http-get               • pop3                                                                https://www.kali.org/tools/hydra/


            - http-post-form         • mssql
            - https                  • mysql
            - smb                    • rdp





Uso de Hydra
 - Sintaxis:
     hydra [opciones] -L lista_usuarios -P lista_contraseñas objetivo y servicio
 - Uso con un usuario concreto y una lista de contraseñas (diccionario):
     hydra -l pepe -P /usr/share/wordlists/rockyou.txt ssh://192.168.1.10:22 -t 4 -V -f -o resultados.txt
 - Descripción de opciones:
     -l pepe -> usuario único (usar `-L` para incluir un fichero con muchos usuarios)
     -P lista.txt -> fichero con contraseñas (diccionario)
     ssh://192.168.1.10:22 -> servicio, host objetivo y puerto
     -t 4 -> número de tareas paralelas (hilos o threads)
     -V -> muestra el detalle de cada intento (verbose).
     -f -> para finalizar al encontrar la primera credencial válida (puede haber más de una)
                                                                                                                                    Hydra
     -o -> archivo de salida





Creación de Diccionarios con Crunch
- Crunch es una potente herramienta de generación de diccionarios a partir de un juego de
  caracteres predefinido.
- Es capaz de generar palabras de longitud fija o variable, con o sin patrón, con o sin literales
  incrustados, con un juego de caracteres reducido, con o sin un string de inicio predefinido,
  etc.
- Crunch genera una lista de palabras ordenada alfabéticamente, que conviene aleatorizar
  barajándola con el comando shuf (shuffle) de Linux.





Ataques Basados en Clave vía SSH
 - La mejor forma de evitar ataques basados en clave via SSH es ajustar la configuración
   del servidor de forma refinada, de forma que se limiten los accesos generalistas, tanto
   manuales como basados en robots, y después mantener una vigilancia constante para
   cerrar accesos en caso de detectar ataques de este tipo.
 - Para ello, el proceso servidor SSH dispone de un gran número de parámetros de
   configuración, que permiten controlar su funcionamiento con gran precisión.
 - Dicha configuración se almacena en el fichero /etc/ssh/sshd_config y cada vez que se
   altera requiere el reinicio del servidor SSH (sudo systemctl restart sshd).
 - En esta práctica se prepararán una máquina de ataque (kalitest) y otra máquina objetivo
   (kalisoc), y se lanzarán ataques basados en clave desde la primera a la segunda.
 - El primer ataque se efectuará desactivando las protecciones y averiguará rápidamente
   las credenciales, mientras que el segundo ataque se efectuará tras activar todas las
   protecciones, con objeto de observar la diferencia entre ambos escenarios.


Ataque basado en clave – Configuración del Servidor SSH
 - El fichero de configuración contiene parámetros que sirven para diferentes
   propósitos. Entre ellos hay un grupo de ajustes que permiten retrasar y
   dificultar los ataques con Fuerza Bruta y con Diccionarios.
 - Un ataque con Diccionario puede tener éxito en función de la presencia de las
   credenciales buscadas en el mismo, pero un ataque con Fuerza Bruta siempre
   tiene éxito, antes o después.
 - Un ataque con Fuerza Bruta prueba todas las combinaciones posibles de
   usuarios y claves, por lo que puede tardar minutos, horas, días, meses o años,
   pero siempre conseguirá encontrar las credenciales de acceso.
 - La estrategia para frenar estos ataques deberá estar basada en una
   combinación de factores tales como retraso en la respuesta, limitación del
   número de intentos, recorte del tiempo de introducción de credenciales,
   cierre de la sesión para obligar a su restablecimiento, etc.



Alta del Usuario a Atacar en la Máquina Objetivo
 - Para implementar el escenario de prueba, se dará de alta un usuario sencillo
   en la máquina objetivo que, a su vez, tendrá una clave simple.
 - Se podrá comprobar que, aun tratándose de credenciales aparentemente
   fáciles de romper, los tiempos de trabajo no son nada desdeñables debido a
   que, tras un fallo de autentificación, el Servidor SSH irá incrementando
   progresivamente los tiempos de respuesta para disuadir al posible atacante.
 - La disuasión funciona con atacantes humanos, pero no descorazona a los
   robots, que seguirán atacando a pesar de todo, no obstante, si se refina lo
   suficiente la configuración, se puede conseguir que su trabajo se extienda
   muchísimo en el tiempo.
 - Por esta razón, la maniobra clave en una estrategia de protección frente a
   este tipo de ataques es cambiar la clave a menudo y hacerla muy
   complicada, pues cada vez que se cambie la clave, el robot deberá empezar
   su ataque desde el principio.


Alta del Usuario a Atacar en la Máquina Objetivo kalisoc
 El escenario de la práctica será el
 siguiente:
 - Máquina objetivo: kalisoc
 - Máquina atacante: kalitest

 En la máquina objetivo se dará de alta un
 usuario con credenciales sencillas, para
 poder completar la práctica de forma
 rápida:
 - Usuario: ab
 - Clave: a1




Preparación del Entorno de Ataque en kalitest
- En la máquina de ataque kalitest se creará un conjunto de sencillos scripts que permitirán
  repetir el ataque de forma secuenciada las veces que sea necesario.
- Estos scripts se ubicarán en el directorio siguiente:
   /home/kali/LAB_HYDRA
- En primer lugar se instalará la herramienta Crunch para fabricación de diccionarios:
   sudo apt update
   sudo apt install crunch





Preparación del Entorno de Ataque en kalitest
- Acto seguido se instalará la herramienta Hydra como logon cracker:
   sudo apt update
   sudo apt install hydra





Script – 0.limpiar_directorio
- Script de limpieza de restos de ejecuciones anteriores del proceso de ataque.

- Contenido del script:
   rm *.txt
   rm hydra.restore





Script – 1.crear_usuarios
- Script de creación del diccionario de usuarios.
- Para la creación de los ficheros de credenciales se utilizará una de las herramientas de código
  abierto más populares para la creación de diccionarios, la herramienta Crunch.
- Crunch permite crear diccionarios inmensos con muchísimas combinaciones de caracteres
  con una sola instrucción (ver manual de Crunch en Linux).
- En este caso, se creará un diccionario de usuarios que contendrá todas las combinaciones
  posibles de dos letras minúsculas.

- Contenido del script:
   crunch 2 2 -t @@ -o usuarios.txt





Script – 2.crear_claves
- Script de creación del diccionario de claves.
- Para la creación del diccionario de claves también se utilizará Crunch.
- En este caso, el fichero resultante contendrá todas las combinaciones posibles de una letra
  minúscula y de un número.
- Se sabe que los diccionarios de Usuarios y Claves de este escenario tienen que estar
  compuestos de esta forma porque previamente se habrá obtenido información mediante
  Ingeniería Social, esto es, puro espionaje.
- El espionaje se podrá efectuar a través de personas o a través de Stealers, Keyloggers y
  aplicaciones similares.

- Contenido del script:
   crunch 2 2 -t @% -o claves.txt




Script – 3.lanzar_hydra
- Script de lanzamiento de hydra.

- Contenido del script con diferentes ataques, descomentando el que proceda en cada caso:
# Ataque con 4 threads (incluir –V antes de –f para ver el detalle de los intentos)
hydra -L usuarios.txt -P claves.txt -o resultados.txt -t 4 -V -f -I ssh://10.1.1.10:22


# Ataque con 64 threads (máximo permitido por Hydra)
# hydra -L usuarios.txt -P claves.txt -o resultados.txt -t 64 -V -f -I ssh://10.1.1.10:22


# Ataque con 64 threads y más tiempo de timeout
# hydra -L usuarios.txt -P claves.txt -o resultados.txt -t 64 -V -f -I ssh://10.1.1.10:22 -w 10





Reducción de Protecciones del Servidor SSH en kalisoc
- Editar el fichero de configuración de ssh y modificar los parámetros indicados a continuación:
    sudo nano /etc/ssh/sshd_config
- MaxStartups. Controla cuántas conexiones no autentificadas simultáneas acepta el demonio antes de
  empezar a rechazar/aleatorizar. Formato: start[:rate[:full]].
    - Ejemplo permisivo para pruebas: MaxStartups 100:100:200
- MaxAuthTries. Intentos de autenticación por conexión (por defecto suele ser 3 ó 6).
    - Para pruebas aumentar: MaxAuthTries 50
- MaxSessions. Número de sesiones por conexión multiplexada: MaxSessions 50
- LoginGraceTime. Tiempo en segundos para completar la autenticación.
    - Si Hydra genera timeouts, aumentarlo ayuda al atacante: LoginGraceTime 3m
- PasswordAuthentication. Si está en “no”, no se podrá usar fuerza bruta por contraseña.
    - Para pruebas: PasswordAuthentication yes
- Después de editar, comprobar la sintaxis del fichero y reiniciar el servicio:
    sudo sshd -t
    sudo systemctl restart sshd




Lanzamiento del Ataque y Descubrimiento de Usuario y Clave
 - Finalmente, se lanza el ataque con la herramienta Hydra y los diccionarios generados.
 - Hydra empieza a probar y va dando estadísticas del tiempo que durará su ataque, en
   función de los tiempos de respuesta y de la configuración del servidor objetivo.
 - La máquina objetivo va endureciendo sus condiciones ante la abundancia de fallos.
 - Hydra consigue efectuar alrededor de 91 intentos por minuto con cuatro procesos en
   paralelo, y al final da con las claves en 5 minutos aproximadamente pues, al empezar con
   “a”, ambas credenciales se encuentran al principio de los diccionarios.
 - Cada sesión fallida hace esperar al atacante, pero en paralelo hay otras sesiones que
   atacan constantemente, por lo que no sirve de nada hacer esperar al que ataca.
 - Otro dato importante a observar es la estadística de los tiempos de terminación pues, tras
   3 minutos de ataque aproximadamente, Hydra estima que tardaría en barrer los
   diccionarios completos un total de casi 35 horas, con las condiciones de la máquina
   objetivo. Además, se puede ver que este tiempo va aumentando progresivamente.
 - Los diccionarios se pueden barajar o aleatorizar con el comando shuf (shuffle).



Lanzamiento del Ataque y Descubrimiento de Usuario y Clave





Ataques de denegación de servicios
 - Si se analiza la situación en ambas máquinas, se verá que hay una media de 4
   procesos de ataque en la máquina origen y una media de 8 sesiones trabajando
   o esperando en la máquina destino, produciéndose una denegación de servicio
   de forma periódica.
 - Así pues, el ataque es casi constante a pesar de los tiempos de espera.





Refuerzo de Seguridad en el Acceso SSH

 - Si se detectan ataques con clave de este tipo, con fuerza bruta o con diccionario, es
   posible evitar la denegación de servicio ajustando los parámetros de seguridad en el
   servidor ssh.
 - El primer parámetro interesante para nuestro propósito es LoginGraceTime.
 - Esta variable especifica el tiempo en segundos en el que la pantalla de Login estará
   disponible para introducir las credenciales.
 - Es un puro timeout y cuando se cumple se cierra automáticamente la pantalla de Login.
 - Es bueno que esté activado, pues así se evitará que haya pantallas de Login ya abiertas
   durante un tiempo indefinido, esperando a que alguien pruebe algo. Llegar a abrir una
   pantalla de Login tiene un coste, pues hay que saltar por encima de Switches y Firewalls
   para hacerlo. Así pues, si se cierra, se obligará a la persona o al robot atacantes a
   empezar con todo desde el principio.



Refuerzo de Seguridad en el Acceso SSH

 - Este parámetro es importante de cara a la introducción manual de credenciales, por lo
   que sólo afectará a los intentos de acceso efectuados por personas o por parte de
   robots simuladores de comportamiento humano. Se aprovechará asimismo para
   desactivar el login directo de root a través de SSH.
 - En términos de tiempos, muchos robots tienen un comportamiento aleatorio para
   despistar a los observadores y a los técnicos de los SOCs, esto es, pudiendo atacar a
   régimen constante y a toda velocidad, intentan aleatorizar los tiempos de ataque para
   simular comportarse como personas.
 - En estos casos es de especial utilidad este parámetro, pues muchas sesiones acabarán
   temporizando.
    LoginGraceTime 15
    PermitRootLogin no





Limitar el Número de Logins Fallidos
- El parámetro MaxAuthTries es el que más dolores de cabeza ocasiona a los hackers.
- Este parámetro limita el número de veces que un atacante puede introducir una
  contraseña incorrecta y que el sistema se la siga solicitando.
- En sistemas poco expuestos conviene dejar el valor clásico de 3 oportunidades,
  pero si el sistema es frontal, perimetral o muy expuesto hay ponerlo a 1.
- Esto tiene mucho coste para el hacker, pues normalmente ha tenido que saltar
  varias vallas para llegar hasta el punto de Login. Si la sesión se desconecta tras un
  solo fallo, ello obliga a volver a saltar todas las vallas de nuevo, desanimando a los
  humanos y retrasando el trabajo de los robots.
- Los robots no se desaniman, pero sí es cierto que bastantes de los que atacan en
  red dejan de intentar el ataque si la sesión se libera a la primera, pues interpretan
  que se trata de un problema de networking.
   MaxAuthTries 2




Limitar el Número de Sesiones por Conexión Multiplexada
 - MaxSessions. Número de sesiones por conexión multiplexada, esto es,
   número de puertos a utilizar en paralelo durante un ataque:
    MaxSessions 1





Limitar el Número de Logins Simultáneos
 - La directiva MaxStartups 100:100:200 controla cuántas conexiones SSH no
   autentificadas simultáneamente permite sshd.
 - La sintaxis es: MaxStartups inicio:porcentaje:máximo
 - Por tanto:
    - 100 - hasta 100 conexiones no autentificadas, sshd las acepta normalmente.
    - 100% - a partir de esas 100 conexiones, sshd empieza a rechazar conexiones aleatoriamente.
    - 200 - cuando se alcanzan 200 conexiones no autentificadas, se rechazan todas las nuevas.
 - Así pues, 100:100:200 significa que entre 100 y 200 conexiones, la probabilidad de
   rechazo crece desde el 0% hasta el 100%.





Limitar el Número de Logins Simultáneos
- Los parámetros anteriores afectan intrínsecamente a cada una de las sesiones, no
  obstante, el parámetro MaxStartups afecta al procesamiento paralelo, que es
  precisamente consecuencia de un ataque masivo y que es el que realmente puede
  hacer entrar en denegación de servicio.
- Ocasionar una denegación de servicio es algo sumamente sencillo de conseguir
  con máquinas dedicadas que estén lanzando muchos procesos de ataque
  concurrentes.
- Este parámetro especifica el número máximo de pantallas de Login simultáneas
  que un atacante puede tener. No afecta al número de sesiones que puede tener
  abiertas un usuario en particular, sino al número de intentos de Login simultáneos.
- Si se le da el valor de 1 se reducirá muchísimo la efectividad de los ataques, puesto
  que sólo podrá haber una pantalla de Login por usuario en un momento dado,
  dificultando los ataques por Fuerza Bruta que se efectúen desde la misma IP y
  obligando al atacante o al robot a utilizar muchísimas IPs diferentes para efectuar
  un ataque masivo basado en clave.
   MaxStartups 1




Activación de Protecciones y Relanzamiento del Ataque
 - Una vez activadas todas estas protecciones, se limpia el entorno de ataque
   borrando los ficheros de restore de Hydra y se relanza el ataque masivo.                                                   Hydra

 - Se verá que las acciones efectuadas han tenido éxito, pues el ataque con
   hydra es rechazado en primera instancia.





Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
