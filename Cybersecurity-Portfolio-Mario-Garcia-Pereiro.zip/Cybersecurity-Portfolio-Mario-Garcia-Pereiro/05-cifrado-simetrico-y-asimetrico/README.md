# Cifrado simétrico y asimétrico

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Ejercicios de Cifrado Simétrico y Asimétrico


                                      nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Funciones Hash
- Una Función Criptográfica Hash es un algoritmo matemático que toma cualquier serie de
  caracteres y la convierte en otra serie de caracteres cuya longitud es siempre fija, con
  independencia de la longitud de la cadena de caracteres de partida.
- Así pues, si un hash concreto tiene una longitud de 50 caracteres, no importará que la
  entrada sea una sola palabra o un libro entero, pues la salida será siempre de 50 caracteres.
- Los hashes tienen las siguientes características:
    - No hay dos entradas que produzcan el mismo hash de salida.
    - Si cambia sólo un carácter de la entrada, cambiarán casi todos los de salida.
    - El cálculo de un hash inverso es posible sólo si la entrada es muy simple.
- Hay diferentes tipos de algoritmos hash:
   - MD4, MD5.
   - SHA-1, SHA-2, SHA-3.                   empresas.blogthinkbig.com
   - BLAKE2, BLAKE3.



Uso de las Funciones Hash
- Las funciones hash se aplican sobre las
  claves en claro y se almacena su resultado
  en las bases de datos para chequear las
  credenciales durante el proceso de login.
  Nunca se debe guardar una clave en claro.
- Estas funciones se utilizan también para
  comprobar que un fichero original no ha
  sido alterado. Esto es muy importante,
  sobre todo si se trata de un ejecutable, que
  puede haber sido modificado por un
  malware para incorporar un virus, un
  gusano, un troyano, una backdoor, etc. Las
  funciones que se utilizan con este propósito
  son MD5 y las distintas versiones de SHA.                                                     www.thefastcode.com





Criptografía Simétrica – Características y Problemas
Características de la Criptografía Simétrica:
- Se utiliza la misma clave para cifrar y para descifrar el mensaje.
- Los algoritmos son sencillos de utilizar.
- También son muy eficientes, pues tardan poco tiempo en cifrar y descifrar.
- Se han utilizado desde la antigüedad hasta los años 70.
- Algoritmos más utilizados: DES, 3DES, AES, Blowfish, IDEA.
Problemas de la Criptografía Simétrica:
- Circulación de las Claves. El objetivo es conseguir que tanto emisor como receptor tengan la
  clave correcta, pero ésta no se puede enviar a través del mismo medio inseguro.
- Gestión de las Claves almacenadas. En una empresa con n trabajadores que intercambian
  información cifrada, cada uno de ellos necesitará almacenar n-1 claves distintas y encontrar
  n-1 canales seguros para transmitirlas. Esto es, harían falta (n-1)*(n-1) canales.


Criptografía Asimétrica - Características
Características de la Criptografía Asimétrica:
- Se utilizan dos claves matemáticamente relacionadas, una para cifrar y otra para descifrar.
- La clave de cifrado se denomina Pública y la de descifrado Privada.
- La clave pública garantiza la autenticidad y la procedencia del mensaje.
- La clave privada no se envía a nadie, por lo que nunca se expone.
- Es matemáticamente imposible deducir la clave privada conociendo sólo la pública.
La Criptografía Asimétrica resuelve los dos problemas de la Criptografía Simétrica:
- Circulación de las Claves. No es preciso enviar la clave de cifrado a través de un medio
  seguro, puesto que es pública y sólo el receptor podrá descifrar el mensaje con su clave.
- Gestión de las Claves almacenadas. En una empresa con n trabajadores que intercambian
  información cifrada, sólo hará falta una clave pública general para cifrar y un canal para
  enviar el mensaje. Cada trabajador sólo deberá conocer y custodiar su clave privada.


Problemas de la Criptografía Asimétrica
- Poca eficiencia. Los sistemas tardan mucho tiempo en aplicar las claves, porque deben ser
  muy largas para asegurar la independencia matemática entre ellas.
- Riesgo ante uso repetido. Algunos ataques criptográficos se basan en analizar paquetes
  cifrados. Estos ataques pueden acabar dando con las claves tras análisis intensivos.
- Necesidad de protección de la clave privada. No se deben dejar en lugares accesibles,
  aunque estén protegidos. Hay que guardarlas en un llavero con cifrado simétrico.
- Copia de seguridad del llavero. Es necesario respaldar el llavero por si se estropea el disco
  duro. Los medios de respaldo pueden estar al alcance de más personas de las necesarias.
- Transporte de la clave privada. En el cifrado simétrico suele ser posible recordar la clave. Este
  no es el caso cuando se trata de cifrado asimétrico, pues la clave es tan larga que hay que
  transportar el llavero. Este llavero puede estar en un pendrive, que podrá ser atacado con
  fuerza bruta si se pierde y cae en manos de personas malintencionadas (el llavero suele estar
  cifrado de forma simétrica).



Ejercicio de Cifrado de Datos – La historia de Claudio y Claudina
 - Claudio Romeo Montesco y Claudina Julieta Capuleto tienen algo en común: siempre
   están en las nubes. Por eso sus respectivas y rivales familias les han apodado con
   sobrenombres relacionados con la “cloud”. Además, están enamorados.
 - Intercambian sus mensajes de amor cifrados de forma simétrica con una clave que
   acordaron antes de que sus destinos se separasen.
 - Así pasan algún tiempo, intercambiando mensajes de forma secreta, hasta que un día
   aciago uno de sus familiares más cotillas, Teobaldo, intercepta uno de estos mensajes,
   averigua la clave y monta un escándalo en el Instagram de Verona.





Ejercicio de Cifrado de Datos – La historia de Claudio y Claudina
                                                                 - Claudio y Claudina no saben qué
                                                                   hacer, y acuden a Fray Lorenzo,
                                                                   que después de reflexionar unos
                                                                   instantes, acaba sentenciando:
                                                                   “la solución a vuestro problema
                                                                   es emplear un cifrado asimétrico;
                                                                   cada uno de vosotros conocerá
                                                                   su clave privada, y además sabrá
                                                                   con certeza que el mensaje
                                                                   recibido proviene de su amado o
                                                                   su amada, pues él o ella lo habrá
                                                                   cifrado con la clave pública
                                                                   recíproca, que se intercambiaron
                                                                   de forma exclusiva”.



GNU Privacy Guard – Configuración y Algoritmos Soportados





Crear Fichero Texto y Cifrar




         Contraseña: arpegio




Enviar fichero a Claudina, que descubre que está cifrado





Claudina descifra el mensaje con la clave que le dio Claudio




                                                                                       Contraseña: arpegio





La Hazaña de Teobaldo Brutto


     teobaldo_brutto                  …
                                                                  Les gusta a paulo_scemo y 14.345 personas más


                                                    teobaldo_brutto ya están estos dos pardillos enviándose cartitas
                                                    tontas otra vez, nunca aprenderán, esto va a acabar como una
                                                    tragedia griega…




                                                       - Todo iba fenomenal, pero el malvado Teobaldo la lía
                                                         parda en el Instagram de Verona…




Cifrado Asimétrico – Generación de Parejas de Claves
   Así pues, estando la comunicación secreta entre los amantes a pleno rendimiento, Teobaldo
   intercepta un mensaje, consigue la clave mediante sus malas artes, y publica la historia en el
   Instagram de Verona.
   Ellos piden consejo de Fray Lorenzo y deciden emplear un cifrado asimétrico; cada uno de ellos
   conocerá su clave privada, y además sabrá con certeza que el mensaje recibido proviene del
   otro, pues él o ella lo habrá cifrado con la clave pública recíproca, que se intercambiaron de
   forma exclusiva.

   Pareja de claves de Claudio Romeo Montesco:
   - Privada: la password elegida. No desvelar a nadie.
   - Pública: la clave generada para enviar a Claudina.

   Pareja de claves de Claudina Julieta Capuleto:
   - Privada: la password elegida. No desvelar a nadie.
   - Pública: la clave generada para enviar a Claudio.



                                         Generación de Pareja de
                                         Claves de Claudio Romeo
                                         Montesco




                                                       Clave Privada Claudio: arpegio





Generación de Pareja de Claves de Claudio Romeo Montesco





                                            Generación de Pareja de
                                            Claves de Claudina Julieta
                                            Capuleto




                                                   Clave Privada Claudina: acorde_sinfonico





Generación de Pareja de Claves de Claudina Julieta Capuleto





Claudio exporta
su clave pública
 - Tras exportar su clave pública,
   Claudio Romeo escribe una
   última carta de amor para
   Claudina Julieta, con
   contenido secreto.





Claudina exporta
su clave pública
 - Tras exportar su clave pública,
   Claudina Julieta escribe una
   última respuesta de amor
   para Claudio Romeo, con
   contenido secreto.





Claudio y Claudina intercambian sus claves públicas





Claudio y Claudina importan sus recíprocas claves públicas





Claudio y Claudina cifran sus mensajes con las claves recíprocas





Claudio y Claudina intercambian sus mensajes cifrados





Claudio y Claudina descifran los mensajes con sus claves privadas




              Clave privada Claudio: arpegio                   Clave Privada Claudina: acorde_sinfonico


Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
