# Auditoría de un inventario de activos con Medusa

> **Práctica realizada por:** Mario Garcia Pereiro  
> **Ámbito:** Ciberseguridad y hacking ético (ASIR 2)

> **Nota de atribución:** documento adaptado y organizado en Markdown a partir del material docente de la asignatura. El contenido técnico y las instrucciones proceden del documento original del profesor. En los documentos que indican licencia, se conserva la referencia a Creative Commons BY-NC-SA 4.0.

---

Laboratorio – Ataque a un Inventario de Activos con Hydra


                                      nc-sa/4.0/ o envíe una carta a Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




Pliego de Descargo
 - Los ejercicios, herramientas y conocimientos contenidos en la Plataforma de Pentesting
   tienen un propósito exclusivamente formativo, por lo que nunca se deberán utilizar con
   fines maliciosos o delictivos.
 - Ningún miembro del claustro docente o de la administración de este centro, serán
   responsables de los daños directos o indirectos que pudieran derivarse del uso
   inadecuado de estas herramientas, que deberán utilizarse sólo en pruebas contra
   sistemas propios o en el curso de auditorías pactadas con los propietarios de los
   sistemas objetivo de los ataques.




                                         www.peruweek.pe



El Inventario de Activos
  - En este ejercicio se preparará un sencillo inventario de activos o registro de planta, que
    describirá las máquinas de una instalación e incluirá todos los parámetros necesarios
    para gestionarlas adecuadamente, sirviendo como un laboratorio de iniciación a
    MySQL/MariaDB. Tras su creación, se procederá a atacar el inventario con Hydra.
  - Esta base de datos puede llegar a tener miles de filas en una instalación empresarial,
    pues en ella se llegan a recoger los datos de todos los hosts, dispositivos de networking
    y dispositivos IoT.
  - Por lo general, este tipo de bases de datos no sólo se rellenan manualmente, sino que
    se alimentan desde aplicaciones con función de Descubrimiento.
  - La securización de este tipo de inventarios se debe efectuar desde el primer momento,
    mediante las utilidades propias del gestor de base de datos. Además, es conveniente
    generar claves de acceso lo más complicadas posible, pues estas bases de datos son
    objetivos estrella de los ataques con Fuerza Bruta o Diccionarios, por contener toda la
    información clave de los recursos de la empresa.


Actualización del Entorno de Laboratorio
- Antes de comenzar con las
  labores de instalación y
  configuración, se actualizará
  el entorno de laboratorio de
  kalitest de la forma habitual,
  SIN efectuar un upgrade:
 sudo apt update
 sudo apt autoremove
                                     - Este laboratorio debe su nombre a la herramienta
 sudo apt autoclean
                                       clásica Medusa para ataques a bases de datos, que
                                       ya no es compatible con las nuevas versiones de
                                       los gestores, pero que definió en su momento los
                                       estilos de ataque a repositorios relacionales.





Instalación del Gestor de la Base de Datos Relacional
 - En primer lugar, se instalará el Gestor de la Base de Datos MariaDB, que es una
   bifurcación (branch) del original MySQL.
 - MariaDB tiene más eficiencia y está mantenido por una comunidad de usuarios
   muy activa (para problemas de instalación, ver pagina siguiente):
    sudo apt install mariadb-server





Troubleshooting – Instalación MariaDB Server
- En caso de que hubiera problemas de instalación, editar el fichero de fuentes de software:
    sudo nano /etc/apt/sources.list


- Localizar la línea de fuentes de kalli-Rolling:
    deb http://http.kali.org/kali kali-rolling main contrib non-free non-free-firmware


- Insertar una “s” en esta dirección URL para indicar que la descarga será segura:
    deb https://http.kali.org/kali kali-rolling main contrib non-free non-free-firmware


- Salvar el fichero, actualizar los paquetes y relanzar la instalación de mariadb-server:
    sudo apt-get update
    sudo apt autoremove
    sudo apt autoclean
    sudo apt install mariadb-server





Instalación de la Base de Datos Finalizada
                                                                                     sudo systemctl enable mariadb
  - A continuación, se habilitará el arranque con el                                 sudo systemctl start mariadb
    inicio de la máquina y se arrancará el servidor.                                 sudo systemctl status mariadb





Securización de la Base de Datos
- Seguidamente se procederá a securizar la instalación efectuada, ejecutando el script
  nativo de MariaDB al efecto:
  sudo mariadb-secure-installation


- Se seleccionarán las siguientes opciones:
   - Indicar ‘kali’ como clave de root
   - Cambiar a autentificación ‘unix_socket’
   - Eliminar usuarios anónimos
   - Inhabilitar el acceso remoto como ‘root’
   - Eliminar base de datos de test
   - Recargar tabla de privilegios





Creación BD y Usuarios
 - Entrar como root al gestor de base de
   datos:
        mysql -u root –p


 - Crear la base de datos de inventario:
        show databases;
        create database inventario;
        show databases;





Sentencias SQL para Creación y Autorización de los Usuarios
 - Crear los usuarios de trabajo y asignarles las autorizaciones correspondientes:

 create user 'lab1'@'localhost' identified by 'kali';
 create user 'lab2'@'localhost' identified by 'kali';
 create user 'lab3'@'localhost' identified by 'kali';
 create user 'lab4'@'localhost' identified by 'kali';
 grant all privileges on *.* to 'lab1'@'localhost' with grant option;
 grant all privileges on *.* to 'lab2'@'localhost' with grant option;
 grant all privileges on *.* to 'lab3'@'localhost' with grant option;
 grant all privileges on *.* to 'lab4'@'localhost' with grant option;
 flush privileges;





Respuestas de la Creación y Autorización de los Usuarios





Selección de la Base de Datos de Trabajo
- Visualizar las bases de datos existentes y seleccionar la base de datos de administración:
   show databases;
   use mysql;





Visualización de las Tablas de la BD
- Visualizar las tablas existentes en la base de datos de
  administración:
   show tables;





Visualización de Usuarios y de los Permisos del Usuario Activo
                                                                      select user,host from mysql.user;
- Visualizar los usuarios existentes en la base de                    select current_user();
  datos, así como los permisos del usuario activo.                    show grants;





Visualización de los Permisos del Resto de los Usuarios
 - Visualizar los permisos del resto de los usuarios existentes en la base de datos:

    show grants for 'lab1'@'localhost';
    show grants for 'lab2'@'localhost';
    show grants for 'lab3'@'localhost';
    show grants for 'lab4'@'localhost';





Respuestas de la Visualización de Permisos de los Usuarios





Creación de la Tabla Principal en la BD Inventario
 - A continuación, se creará la tabla principal del Registro de Planta en la base de datos del
   inventario de activos, para contener los datos de una instalación ficticia, de la forma
   siguiente:
 Nombre   Dirección IP    Sistema           Modelo Máquina                    Función en el SOC                             Observaciones
  Host      Estática     Operativo
 Router   192.168.1.1    Askey SO              RTF3505VW                      Conexión Internet                                LAN, WiFi
 Switch   192.168.1.20   3com SO         SuperStack 3 3300XM                Three-Legged Switch                         LAN, WiFi Inhabilitada
 DMZ1     192.168.1.21   Raspbian            Raspberry Pi 4B                       IDS / SIEM                           LAN, WiFi Inhabilitada
 DMZ2     192.168.1.22   Raspbian           Raspberry Pi 3B+                     NAS / VAULT                            LAN, WiFi Inhabilitada
  LAB1    192.168.1.23   Linux Mint         MinisForum N34              Laboratorio Ubuntu / Debian                     LAN, WiFi Inhabilitada
  LAB2    192.168.1.24   Raspbian           Raspberry Pi 3B+                Laboratorio Raspbian                        LAN, WiFi Inhabilitada
  LAN1    192.168.1.25   Raspbian            Raspberry Pi 2B            Firewall / Inventario Activos                   LAN, WiFi Inhabilitada





Estructura de la Tabla Principal en la BD Inventario
 La estructura de la tabla será la siguiente:
 - id. Identificador del registro, autogenerado. Entero de tamaño medio
 - nombre_host. Cadena de 30 caracteres.
 - direccion_ip. Cadena de 30 caracteres.
 - sis_op. Cadena de 30 caracteres.
 - modelo. Cadena de 30 caracteres.
 - funcion_soc. Cadena de 30 caracteres.
 - usuario. Cadena de 30 caracteres.
 - password_hash. Cadena de 255 caracteres. Sólo hashes, NUNCA passwords en claro.
 - observaciones. Cadena de 255 caracteres.
 - Clave Primaria. Clave principal o identificador único de cada registro de la tabla.



Sentencia de Creación de la Tabla Principal en la BD Inventario
  CREATE TABLE inventario.principal(
         id MEDIUMINT NOT NULL AUTO_INCREMENT,
         nombre_host CHAR(30) NOT NULL,
         direccion_ip CHAR(30),
         sis_op CHAR(30),
         modelo CHAR(30),
         funcion_soc CHAR(30),
         usuario CHAR(30),
         password_hash CHAR(255),
         observaciones CHAR(255),
         PRIMARY KEY (id) );





Comprobación Tabla
 - Comprobar que la tabla se ha creado correctamente:
    use inventario;
    show tables;
    describe principal;





Inserción de los Datos de los Equipos en la Tabla Principal
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('router', '192.168.1.1', 'Askey SO', 'RTF3505VW', 'Conexion Internet');
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('switch', '192.168.1.20', '3com SO', 'SuperStack 3 3300XM', 'Three-Legged Switch');
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('DMZ1', '192.168.1.21', 'Raspbian', 'Raspberry Pi 4B', 'IDS/SIEM');
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('DMZ2', '192.168.1.22', 'Raspbian', 'Raspberry Pi 3B+', 'NAS/VAULT');
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('LAB1', '192.168.1.23', 'Linux Mint', 'MinisForum N34', 'Laboratorio Ubuntu/Debian');
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('LAB2', '192.168.1.24', 'Raspbian', 'Raspberry Pi 3B+', 'Laboratorio Raspbian');
 insert into principal (nombre_host, direccion_ip, sis_op, modelo, funcion_soc) values
 ('LAN1', '192.168.1.25', 'Raspbian', 'Raspberry Pi 2B', 'Firewall/Inventario Activos');





Respuestas de Inserción de los Datos de los Equipos en la Tabla





Visualización de los Datos de Equipos Insertados en la Tabla
 - Visualizar el contenido de la tabla principal:
    select * from principal;





Asignación del Usuario Administrador a Todos los Equipos
- Asignar el usuario administrador (admin) a todos los equipos de la tabla:
   update principal set usuario='admin';
   select * from principal;





Almacenamiento de los Hashes de las Passwords en la Tabla
 - Durante el proceso de almacenamiento de credenciales y una vez registrados los
   nombres de los usuarios, llega el momento de almacenar la información de sus
   respectivas claves.
 - Este punto constituye uno de los asuntos principales dentro del campo de la
   ciberseguridad. En una base de datos NUNCA se debe almacenar la información de las
   claves en claro, esto es, literalmente.
 - Esto no quiere decir que no se pueda hacer, puesto que al fin y al cabo se trata de una
   cadena de caracteres y el usuario de la base de datos podrá hacer con ella lo que quiera,
   no obstante, se trata de una buena práctica que casi todo el mundo aplica.
 - Almacenar las claves en claro es un grave error puesto que, si un pirata informático
   consiguiera entrar a la base de datos, tendría todas las llaves en la mano.
 - Lo ideal es almacenar el hash obtenido con la correspondiente función de traducción.



Sentencias de Grabación de los Hashes en la Tabla
  update principal set password_hash='pq9wuct4h3gogqrcgerpig' where nombre_host='router';
  update principal set password_hash='qpwi9te230vm9hgqergewr' where nombre_host='switch';
  update principal set password_hash='mvwergjwdsjfvaiueyoiuh' where nombre_host='DMZ1';
  update principal set password_hash='jfgsdptaddrphdfsj6458s' where nombre_host='DMZ2';
  update principal set password_hash='tvrds6e7436uytfiyfuytf' where nombre_host='LAB1';
  update principal set password_hash='soehfiw4uyg5rq94wygrqs' where nombre_host='LAB2';
  update principal set password_hash='poijoijhigufufdfyutfis' where nombre_host='LAN1';





Respuestas de la Grabación de los Hashes de las Passwords





Verificación de la Grabación de los Hashes en la Tabla
- Visualizar el contenido de la tabla principal para verificar la grabación de los hashes:
   select * from principal;





Actualización del Campo Observaciones
- Actualizar inicialmente toda la columna de Observaciones con el mismo valor:
   update principal set observaciones='LAN, No WiFi';





Actualización del Campo Observaciones
- Modificar el valor del campo en el primer registro, que es el único diferente:
   update principal set observaciones='LAN, WiFi' where nombre_host='router';




- Con esta última sentencia ya habrá quedado preparada la base de datos de inventario para
  prácticas de cracking con Hydra al estilo de Medusa.
- A continuación, se preparará un conjunto de scripts sencillos para poder repetir el ataque
  de forma rápida. Esta técnica es habitual dentro de los equipos corporativos de pentesting.



Script – 0.limpiar_directorio
- Script de limpieza de restos de ejecuciones anteriores del proceso de ataque.

- Contenido del script:
   rm *.txt
   rm *.restore





Script – 1.crear_usuarios
- Script de creación del diccionario de usuarios con Crunch.

- Contenido del script:
   crunch 4 4 -t lab% -o usuarios.txt
   shuf usuarios.txt > fichero_usuarios.txt
   rm usuarios.txt





Script – 2.crear_claves
- Script de creación del diccionario de claves con Crunch.

- Contenido del script:
   crunch 4 4 -t kal@ -o claves.txt
   shuf claves.txt > fichero_claves.txt
   rm claves.txt





Script – 3.lanzar_hydra
- Script de lanzamiento de hydra al estilo de Medusa:

- Contenido del script:
# Ataque a la base de datos en local - maximo 4 threads (limitacion de Hydra por handshake)
# Para ver el detalle del ataque insertar la opción -V tras los threads (-t 4)
hydra -L fichero_usuarios.txt -P fichero_claves.txt -t 4 -I mysql://127.0.0.1





Muchas gracias por vuestra atención

---

## Autoría y referencia

- **Realización y documentación del laboratorio:** Mario Garcia Pereiro.
- **Material de partida:** documentación docente facilitada en clase.
- **Licencia indicada en el original cuando aparece:** [Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/).

> Este repositorio documenta prácticas realizadas en un entorno académico y controlado. No se deben ejecutar técnicas de auditoría sobre sistemas o redes sin autorización expresa.
